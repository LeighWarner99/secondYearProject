function confirmDel(){
    return confirm("Are you sure");
}